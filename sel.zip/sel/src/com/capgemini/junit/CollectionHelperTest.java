package com.capgemini.junit;
import junit.framework.Assert;

import org.junit.Test;
import org.junit.AfterClass;
import org.junit.BeforeClass;

import com.capgemini.bin.*;
import com.capgemini.exception.*;
import com.capgemini.collection.*;

public class CollectionHelperTest {
	static Collector collectionHelper;
	static ItemSchema item=null;
	
	@BeforeClass
	public static void beforeClass()
	{
		collectionHelper=new Collector();
		item =new ItemSchema(15,"pears",555.56,456);
		
	}
	@AfterClass
	public static void afterClass()
	{
		collectionHelper=null;
		item=null;
	}
	
	@Test
	public void adddetails() throws ItemException
	{
		collectionHelper.adddetails(item);
		Assert.assertNotNull(collectionHelper.toString());
	}

	

}


